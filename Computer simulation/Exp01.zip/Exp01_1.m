clc
clear

A=fix(1+99*rand(1,12)); %(1)
maxData=max(A);         %(2)
minData=min(A);
B=A;                    %(3)
B(A==maxData)=999;
B(A==minData)=666;
C=reshape(B,3,4);       %(4)
save myData01_1;        %(5)

