clc
clear

load myData01_1;  %(1)

D=rand(3,4);      %(2)  
E1=C+D;
E2=5*C;
E4=C.*D;
E5=C\D;
E6=C/D;
E7=C./D;
E8=C.^2;