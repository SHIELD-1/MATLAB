clc
clear

load myData02_1;
fields={'name','number','sex','score'};
stuStructArray1=cell2struct(stuCellArray1',fields,1);
for i=1:4
stuStructArray1(i).avervge=X(i);
end
stuStructArray2=stuStructArray1;
temp=struct2cell(stuStructArray2);
temp=sortrows(temp',5);
fields={'name','number','sex','score','average'};
stuStructArray3=cell2struct(temp',fields,1);
for i=1:4
   if stuStructArray3(i).average<75
     stuStructArray3(i)
   end
end



