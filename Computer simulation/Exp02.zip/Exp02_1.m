clc
clear


stuCellArray1=cell(4,4);
stuCellArray1{1,1}='zhangsan';
stuCellArray1{1,2}='101200001';
stuCellArray1{1,3}='f';
stuCellArray1{1,4}=fix(60+39*rand(1,4));
stuCellArray1{2,1}='lisi';
stuCellArray1{2,2}='101200002';
stuCellArray1{2,3}='f';
stuCellArray1{2,4}=fix(60+39*rand(1,4));
stuCellArray1{3,1}='wangwu';
stuCellArray1{3,2}='101200003';
stuCellArray1{3,3}='m';
stuCellArray1{3,4}=fix(60+39*rand(1,4));
stuCellArray1{4,1}='zhaoliu';
stuCellArray1{4,2}='101200004';
stuCellArray1{4,3}='m';
stuCellArray1{4,4}=fix(60+39*rand(1,4));
for i=1:4
    X(i)=mean(stuCellArray1{i,4});
end
stuCellArray2=stuCellArray1;
stuCellArray2{4,5}=10;
for i=1:4
    stuCellArray2{i,5}=X(i);
end
stuCellArray3=sortrows(stuCellArray2,5);
save myData02_1;