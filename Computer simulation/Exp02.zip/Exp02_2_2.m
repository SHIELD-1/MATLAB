clc
clear

load myData02_1;
fields={'name','number','sex','score'};
stuStructArray1=cell2struct(stuCellArray1',fields,1);
stuStructArray2=stuStructArray1;
for i=1:4
stuStructArray2(i).average=X(i);
end
[score,index]=sort([stuStructArray2.average]);
stuStructArray3=stuStructArray2(index);
for i=1:4
   if stuStructArray3(i).average<75
     stuStructArray3(i)
   end
end
